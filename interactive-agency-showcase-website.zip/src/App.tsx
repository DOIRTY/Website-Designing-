import { useEffect, useMemo, useState } from "react";

type ThemeMode = "dark" | "light" | "brutal" | "cyber";
type AccentKey = "cyan" | "violet" | "emerald" | "orange";
type RadiusKey = "sharp" | "rounded" | "pill";

type Project = {
  title: string;
  category: string;
  description: string;
  tags: string[];
  gradient: string;
  stats: string[];
};

const themes: Record<
  ThemeMode,
  {
    label: string;
    surface: string;
    surfaceAlt: string;
    text: string;
    muted: string;
    border: string;
    heroGlow: string;
    bgA: string;
    bgB: string;
    bgC: string;
    shadow: string;
  }
> = {
  dark: {
    label: "Dark Modern",
    surface: "rgba(11, 18, 32, 0.7)",
    surfaceAlt: "rgba(15, 23, 42, 0.9)",
    text: "#f8fafc",
    muted: "#94a3b8",
    border: "rgba(148, 163, 184, 0.18)",
    heroGlow: "rgba(34, 211, 238, 0.22)",
    bgA: "#020617",
    bgB: "#0f172a",
    bgC: "#111827",
    shadow: "0 30px 80px rgba(2, 6, 23, 0.55)",
  },
  light: {
    label: "Light Clean",
    surface: "rgba(255, 255, 255, 0.72)",
    surfaceAlt: "rgba(248, 250, 252, 0.95)",
    text: "#0f172a",
    muted: "#475569",
    border: "rgba(148, 163, 184, 0.28)",
    heroGlow: "rgba(59, 130, 246, 0.16)",
    bgA: "#eff6ff",
    bgB: "#f8fafc",
    bgC: "#e2e8f0",
    shadow: "0 26px 80px rgba(148, 163, 184, 0.28)",
  },
  brutal: {
    label: "Neo-Brutalism",
    surface: "rgba(255, 247, 237, 0.92)",
    surfaceAlt: "rgba(255, 255, 255, 0.96)",
    text: "#111111",
    muted: "#3f3f46",
    border: "#111111",
    heroGlow: "rgba(249, 115, 22, 0.18)",
    bgA: "#fde68a",
    bgB: "#fb7185",
    bgC: "#f8fafc",
    shadow: "10px 10px 0 rgba(17,17,17,0.95)",
  },
  cyber: {
    label: "Cyberpunk",
    surface: "rgba(9, 9, 20, 0.78)",
    surfaceAlt: "rgba(17, 24, 39, 0.92)",
    text: "#f5f3ff",
    muted: "#c4b5fd",
    border: "rgba(217, 70, 239, 0.34)",
    heroGlow: "rgba(217, 70, 239, 0.25)",
    bgA: "#09090b",
    bgB: "#1e1b4b",
    bgC: "#0f172a",
    shadow: "0 34px 90px rgba(168, 85, 247, 0.2)",
  },
};

const accents: Record<AccentKey, { label: string; value: string; soft: string }> = {
  cyan: { label: "Cyan", value: "#22d3ee", soft: "rgba(34, 211, 238, 0.22)" },
  violet: { label: "Electric Violet", value: "#8b5cf6", soft: "rgba(139, 92, 246, 0.24)" },
  emerald: { label: "Emerald", value: "#10b981", soft: "rgba(16, 185, 129, 0.24)" },
  orange: { label: "Sunset Orange", value: "#f97316", soft: "rgba(249, 115, 22, 0.24)" },
};

const radii: Record<RadiusKey, { label: string; value: string }> = {
  sharp: { label: "Sharp 0px", value: "0px" },
  rounded: { label: "Rounded 12px", value: "12px" },
  pill: { label: "Pill 24px", value: "24px" },
};

const projects: Project[] = [
  {
    title: "Fintech Mobile App",
    category: "Product Design",
    description:
      "A conversion-focused mobile banking experience with frictionless onboarding, card controls, and animated savings insights.",
    tags: ["UX Strategy", "Motion", "Mobile"],
    gradient: "linear-gradient(135deg, rgba(34,211,238,0.35), rgba(59,130,246,0.15))",
    stats: ["+41% signups", "3.1s onboarding", "NPS 72"],
  },
  {
    title: "E-Commerce Brand",
    category: "Brand System",
    description:
      "A polished storefront design system with editorial layouts, immersive product cards, and checkout simplification.",
    tags: ["Branding", "Commerce", "Content"],
    gradient: "linear-gradient(135deg, rgba(249,115,22,0.35), rgba(244,114,182,0.14))",
    stats: ["+28% AOV", "18% faster checkout", "4.8★ UX"],
  },
  {
    title: "SaaS Dashboard",
    category: "Interface Design",
    description:
      "A modular analytics workspace built for clarity, collaboration, and scalable component-driven product growth.",
    tags: ["Dashboard", "Data Viz", "B2B"],
    gradient: "linear-gradient(135deg, rgba(16,185,129,0.35), rgba(20,184,166,0.15))",
    stats: ["62% task completion", "11 widget types", "WCAG AA"],
  },
];

const uiBadges = ["Primary", "Live Tokens", "Hover State", "Smart Validation"];

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>("dark");
  const [accent, setAccent] = useState<AccentKey>("cyan");
  const [radius, setRadius] = useState<RadiusKey>("rounded");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showContact, setShowContact] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", project: "", budget: "" });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof form, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  const activeTheme = themes[theme];
  const activeAccent = accents[accent];
  const activeRadius = radii[radius];

  const cssVars = useMemo(
    () =>
      ({
        "--bg-a": activeTheme.bgA,
        "--bg-b": activeTheme.bgB,
        "--bg-c": activeTheme.bgC,
        "--surface": activeTheme.surface,
        "--surface-alt": activeTheme.surfaceAlt,
        "--text": activeTheme.text,
        "--muted": activeTheme.muted,
        "--border": activeTheme.border,
        "--accent": activeAccent.value,
        "--accent-soft": activeAccent.soft,
        "--glow": activeTheme.heroGlow,
        "--radius": activeRadius.value,
        "--shadow": activeTheme.shadow,
      }) as React.CSSProperties,
    [activeAccent.soft, activeAccent.value, activeRadius.value, activeTheme]
  );

  useEffect(() => {
    document.documentElement.style.scrollBehavior = "smooth";
  }, []);

  const validate = () => {
    const nextErrors: Partial<Record<keyof typeof form, string>> = {};

    if (!form.name.trim()) nextErrors.name = "Tell us your name.";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) nextErrors.email = "Enter a valid email address.";
    if (form.project.trim().length < 12) nextErrors.project = "Share a few details about your project.";
    if (!form.budget) nextErrors.budget = "Choose a budget range.";

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(false);

    if (validate()) {
      setSubmitted(true);
      setShowContact(true);
      setForm({ name: "", email: "", project: "", budget: "" });
      setErrors({});
    }
  };

  return (
    <div style={cssVars} className="min-h-screen bg-[radial-gradient(circle_at_top_left,var(--accent-soft),transparent_30%),linear-gradient(135deg,var(--bg-a),var(--bg-b)_40%,var(--bg-c))] text-[var(--text)] transition-all duration-500">
      <style>{`
        :root { color-scheme: dark; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Inter, ui-sans-serif, system-ui, sans-serif; background: linear-gradient(135deg, var(--bg-a), var(--bg-b), var(--bg-c)); color: var(--text); }
        a { color: inherit; text-decoration: none; }
        .glass {
          background: linear-gradient(180deg, color-mix(in srgb, var(--surface) 88%, transparent), color-mix(in srgb, var(--surface-alt) 92%, transparent));
          border: 1px solid var(--border);
          box-shadow: var(--shadow);
          backdrop-filter: blur(18px);
        }
        .chip, .token, .pill, .field, .btn, .card, .modal, .ui-demo, .nav-shell { border-radius: var(--radius); }
        .grid-fade {
          background-image: linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px);
          background-size: 44px 44px;
          mask-image: linear-gradient(to bottom, rgba(0,0,0,.35), rgba(0,0,0,.02));
        }
        .floaty { animation: floaty 6s ease-in-out infinite; }
        .pulse-ring { animation: pulseRing 2s ease-out infinite; }
        .shine:hover { transform: translateY(-4px); box-shadow: 0 14px 40px var(--accent-soft); }
        .switch-dot { transition: transform .25s ease; }
        .switch[data-on='true'] .switch-dot { transform: translateX(20px); }
        .card-visual::after {
          content: '';
          position: absolute;
          inset: auto 10% 12% 10%;
          height: 2px;
          background: linear-gradient(90deg, transparent, var(--accent), transparent);
          box-shadow: 0 0 20px var(--accent);
        }
        .focus-ring:focus {
          outline: none;
          border-color: var(--accent);
          box-shadow: 0 0 0 4px var(--accent-soft);
          transform: translateY(-1px);
        }
        @keyframes floaty {
          0%,100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }
        @keyframes pulseRing {
          0% { transform: scale(.9); opacity: .55; }
          100% { transform: scale(1.3); opacity: 0; }
        }
        @media (max-width: 1024px) {
          .token-panel { position: static !important; }
        }
      `}</style>

      <div className="grid-fade pointer-events-none fixed inset-0 opacity-40" />

      <header className="sticky top-0 z-30 px-4 py-4 sm:px-6 lg:px-8">
        <div className="nav-shell glass mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <a href="#top" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-[calc(var(--radius)+4px)] bg-[var(--accent-soft)] text-lg font-black text-[var(--accent)]">S</div>
            <div>
              <div className="text-sm font-semibold tracking-[0.24em] text-[var(--muted)] uppercase">StyleCraft Studio</div>
              <div className="text-xs text-[var(--muted)]">Interactive web design agency</div>
            </div>
          </a>
          <nav className="hidden gap-6 text-sm md:flex">
            <a href="#work" className="text-[var(--muted)] transition hover:text-[var(--text)]">Work</a>
            <a href="#system" className="text-[var(--muted)] transition hover:text-[var(--text)]">UI Kit</a>
            <a href="#contact" className="text-[var(--muted)] transition hover:text-[var(--text)]">Contact</a>
          </nav>
        </div>
      </header>

      <main id="top" className="relative px-4 pb-16 sm:px-6 lg:px-8">
        <section className="mx-auto grid max-w-7xl gap-8 pt-8 lg:grid-cols-[minmax(0,1fr)_320px] lg:pt-12">
          <div className="space-y-8">
            <div className="glass relative overflow-hidden p-8 sm:p-10">
              <div className="absolute right-8 top-8 hidden sm:block">
                <div className="floaty relative flex items-center gap-3 rounded-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-2 text-xs text-[var(--muted)]">
                  <span className="relative flex h-3 w-3 items-center justify-center">
                    <span className="pulse-ring absolute inline-flex h-3 w-3 rounded-full bg-[var(--accent)]" />
                    <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[var(--accent)]" />
                  </span>
                  Live design token playground
                </div>
              </div>

              <div className="max-w-3xl space-y-6">
                <div className="chip inline-flex items-center gap-2 border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-2 text-sm text-[var(--muted)]">
                  <span className="h-2 w-2 rounded-full bg-[var(--accent)]" />
                  Strategy • UI Systems • Frontend Craft
                </div>
                <div className="space-y-4">
                  <h1 className="max-w-3xl text-5xl font-black tracking-tight sm:text-6xl lg:text-7xl">
                    We Craft <span className="text-[var(--accent)]">Digital</span> Experiences
                  </h1>
                  <p className="max-w-2xl text-lg leading-8 text-[var(--muted)] sm:text-xl">
                    StyleCraft Studio designs expressive, conversion-driven interfaces with polished motion, scalable systems, and immersive product storytelling.
                  </p>
                </div>
                <div className="flex flex-col gap-4 sm:flex-row">
                  <a href="#work" className="btn shine inline-flex items-center justify-center border border-transparent bg-[var(--accent)] px-6 py-3 font-semibold text-slate-950 transition duration-300">
                    Explore Work
                  </a>
                  <button
                    type="button"
                    onClick={() => setShowContact(true)}
                    className="btn inline-flex items-center justify-center border border-[var(--border)] bg-[var(--surface-alt)] px-6 py-3 font-semibold text-[var(--text)] transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
                  >
                    Try Design Studio
                  </button>
                </div>
              </div>

              <div className="mt-10 grid gap-4 sm:grid-cols-3">
                {[
                  ["12+", "Launch-ready design systems"],
                  ["97%", "Client satisfaction score"],
                  ["4 weeks", "Avg concept-to-prototype sprint"],
                ].map(([value, label]) => (
                  <div key={label} className="card border border-[var(--border)] bg-[var(--surface-alt)] p-5">
                    <div className="text-2xl font-bold text-[var(--accent)]">{value}</div>
                    <div className="mt-2 text-sm text-[var(--muted)]">{label}</div>
                  </div>
                ))}
              </div>
            </div>

            <section id="work" className="space-y-5">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="text-sm uppercase tracking-[0.3em] text-[var(--muted)]">Portfolio work</p>
                  <h2 className="mt-2 text-3xl font-bold">Selected agency launches</h2>
                </div>
                <p className="hidden max-w-lg text-right text-sm text-[var(--muted)] lg:block">
                  Each concept blends brand clarity, visual hierarchy, and production-minded component systems.
                </p>
              </div>

              <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {projects.map((project) => (
                  <article key={project.title} className="card glass overflow-hidden transition duration-300 hover:-translate-y-1">
                    <div className="card-visual relative h-48 overflow-hidden border-b border-[var(--border)]" style={{ background: project.gradient }}>
                      <div className="absolute inset-4 rounded-[calc(var(--radius)+2px)] border border-white/10 bg-[linear-gradient(135deg,rgba(255,255,255,0.18),rgba(255,255,255,0.02))]" />
                      <div className="absolute inset-x-6 top-6 flex gap-2">
                        {project.tags.map((tag) => (
                          <span key={tag} className="pill border border-white/15 bg-black/15 px-3 py-1 text-xs text-white/90 backdrop-blur-md">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4 p-6">
                      <div>
                        <div className="text-xs uppercase tracking-[0.28em] text-[var(--muted)]">{project.category}</div>
                        <h3 className="mt-2 text-2xl font-semibold">{project.title}</h3>
                      </div>
                      <p className="text-sm leading-7 text-[var(--muted)]">{project.description}</p>
                      <button
                        type="button"
                        onClick={() => setSelectedProject(project)}
                        className="btn w-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3 text-sm font-semibold transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
                      >
                        View Case Study
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </section>

            <section id="system" className="glass space-y-6 p-8">
              <div className="space-y-3">
                <p className="text-sm uppercase tracking-[0.3em] text-[var(--muted)]">Design system UI kit</p>
                <h2 className="text-3xl font-bold">Interactive component language</h2>
                <p className="max-w-3xl text-[var(--muted)]">
                  Explore how buttons, inputs, badges, toggles, and cards respond to the current token settings. The entire showcase inherits the active accent, radius, and theme mode.
                </p>
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <div className="ui-demo border border-[var(--border)] bg-[var(--surface-alt)] p-6">
                  <h3 className="text-lg font-semibold">Buttons & badges</h3>
                  <div className="mt-5 flex flex-wrap gap-3">
                    <button className="btn bg-[var(--accent)] px-5 py-3 font-semibold text-slate-950 transition hover:brightness-110">Primary action</button>
                    <button className="btn border border-[var(--border)] bg-transparent px-5 py-3 font-semibold transition hover:border-[var(--accent)] hover:text-[var(--accent)]">Secondary</button>
                    {uiBadges.map((badge) => (
                      <span key={badge} className="pill border border-[var(--border)] bg-[var(--accent-soft)] px-3 py-2 text-sm text-[var(--text)]">
                        {badge}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="ui-demo border border-[var(--border)] bg-[var(--surface-alt)] p-6">
                  <h3 className="text-lg font-semibold">Inputs & micro-interactions</h3>
                  <div className="mt-5 space-y-4">
                    <input className="field focus-ring w-full border border-[var(--border)] bg-transparent px-4 py-3 text-sm transition" placeholder="Email for launch updates" />
                    <div className="flex items-center justify-between gap-4 border border-[var(--border)] px-4 py-3">
                      <div>
                        <div className="font-medium">Prototype review mode</div>
                        <div className="text-sm text-[var(--muted)]">Toggle animated walkthroughs</div>
                      </div>
                      <button type="button" data-on="true" className="switch relative h-8 w-14 rounded-full bg-[var(--accent-soft)] p-1">
                        <span className="switch-dot block h-6 w-6 rounded-full bg-[var(--accent)]" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="ui-demo border border-[var(--border)] bg-[var(--surface-alt)] p-6 lg:col-span-2">
                  <h3 className="text-lg font-semibold">Card containers & layout rhythm</h3>
                  <div className="mt-5 grid gap-4 md:grid-cols-3">
                    {[
                      "Atomic components ready for scaling teams.",
                      "Accessible contrast and hover feedback built-in.",
                      "Unified spacing, radius, and accent tokens in sync.",
                    ].map((copy, index) => (
                      <div key={index} className="card border border-[var(--border)] bg-[linear-gradient(180deg,var(--surface),transparent)] p-5 transition hover:-translate-y-1">
                        <div className="mb-4 h-10 w-10 rounded-[calc(var(--radius)+2px)] bg-[var(--accent-soft)]" />
                        <p className="text-sm leading-7 text-[var(--muted)]">{copy}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section id="contact" className="glass p-8">
              <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
                <div className="space-y-4">
                  <p className="text-sm uppercase tracking-[0.3em] text-[var(--muted)]">Start a project</p>
                  <h2 className="text-3xl font-bold">Interactive contact form</h2>
                  <p className="text-[var(--muted)]">
                    Tell us what you're building and we’ll shape a design direction with production-ready thinking, polished interactions, and a sharp digital identity.
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowContact(true)}
                    className="btn inline-flex border border-[var(--border)] bg-[var(--surface-alt)] px-5 py-3 font-semibold transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
                  >
                    Open floating inquiry modal
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-sm text-[var(--muted)]">Your name</label>
                      <input
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="field focus-ring w-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3 text-sm transition"
                        placeholder="Alex Morgan"
                      />
                      {errors.name && <p className="mt-2 text-sm text-rose-400">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="mb-2 block text-sm text-[var(--muted)]">Email</label>
                      <input
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="field focus-ring w-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3 text-sm transition"
                        placeholder="alex@brand.com"
                      />
                      {errors.email && <p className="mt-2 text-sm text-rose-400">{errors.email}</p>}
                    </div>
                  </div>

                  <div>
                    <label className="mb-2 block text-sm text-[var(--muted)]">Project vision</label>
                    <textarea
                      value={form.project}
                      onChange={(e) => setForm({ ...form, project: e.target.value })}
                      className="field focus-ring min-h-32 w-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3 text-sm transition"
                      placeholder="We need a premium product site with a modular design system and animated storytelling sections."
                    />
                    {errors.project && <p className="mt-2 text-sm text-rose-400">{errors.project}</p>}
                  </div>

                  <div>
                    <label className="mb-2 block text-sm text-[var(--muted)]">Budget range</label>
                    <select
                      value={form.budget}
                      onChange={(e) => setForm({ ...form, budget: e.target.value })}
                      className="field focus-ring w-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3 text-sm transition"
                    >
                      <option value="">Select a budget</option>
                      <option>$8k - $15k</option>
                      <option>$15k - $30k</option>
                      <option>$30k+</option>
                    </select>
                    {errors.budget && <p className="mt-2 text-sm text-rose-400">{errors.budget}</p>}
                  </div>

                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                    <button type="submit" className="btn bg-[var(--accent)] px-6 py-3 font-semibold text-slate-950 transition hover:brightness-110">
                      Submit inquiry
                    </button>
                    <p className="text-sm text-[var(--muted)]">Dynamic validation appears instantly when required details are missing.</p>
                  </div>

                  {submitted && (
                    <div className="rounded-[var(--radius)] border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
                      Thanks — your inquiry looks great. We’ll reply with a tailored design direction shortly.
                    </div>
                  )}
                </form>
              </div>
            </section>
          </div>

          <aside className="token-panel glass h-fit p-5 lg:sticky lg:top-24">
            <div className="space-y-6">
              <div>
                <p className="text-sm uppercase tracking-[0.3em] text-[var(--muted)]">Design tokens</p>
                <h2 className="mt-2 text-2xl font-bold">Playground</h2>
                <p className="mt-2 text-sm leading-6 text-[var(--muted)]">
                  Change the design language globally and watch every panel, card, button, and form element update in real time.
                </p>
              </div>

              <div>
                <div className="mb-3 text-sm font-semibold">Theme mode</div>
                <div className="grid gap-3">
                  {(Object.entries(themes) as [ThemeMode, (typeof themes)[ThemeMode]][]).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => setTheme(key)}
                      className={`token border px-4 py-3 text-left text-sm transition ${
                        theme === key
                          ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--text)]"
                          : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--muted)] hover:text-[var(--text)]"
                      }`}
                    >
                      {value.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="mb-3 text-sm font-semibold">Accent color</div>
                <div className="flex flex-wrap gap-3">
                  {(Object.entries(accents) as [AccentKey, (typeof accents)[AccentKey]][]).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => setAccent(key)}
                      aria-label={value.label}
                      className={`h-11 w-11 rounded-full border-2 transition ${accent === key ? "scale-110 border-white" : "border-transparent opacity-80 hover:opacity-100"}`}
                      style={{ background: value.value }}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="mb-3 text-sm font-semibold">Border radius</div>
                <div className="grid gap-3">
                  {(Object.entries(radii) as [RadiusKey, (typeof radii)[RadiusKey]][]).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => setRadius(key)}
                      className={`token border px-4 py-3 text-left text-sm transition ${
                        radius === key
                          ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--text)]"
                          : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--muted)] hover:text-[var(--text)]"
                      }`}
                    >
                      {value.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-alt)] p-4 text-sm text-[var(--muted)]">
                <div className="font-semibold text-[var(--text)]">Current settings</div>
                <ul className="mt-3 space-y-2">
                  <li>Mode: {activeTheme.label}</li>
                  <li>Accent: {activeAccent.label}</li>
                  <li>Radius: {activeRadius.label}</li>
                </ul>
              </div>
            </div>
          </aside>
        </section>
      </main>

      {selectedProject && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md">
          <div className="modal glass w-full max-w-2xl p-6 sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-[var(--muted)]">Interactive case study</div>
                <h3 className="mt-2 text-3xl font-bold">{selectedProject.title}</h3>
              </div>
              <button onClick={() => setSelectedProject(null)} className="btn border border-[var(--border)] px-3 py-2 text-sm text-[var(--muted)] transition hover:text-[var(--text)]">
                Close
              </button>
            </div>
            <div className="mt-6 h-56 rounded-[calc(var(--radius)+4px)] border border-[var(--border)]" style={{ background: selectedProject.gradient }} />
            <p className="mt-6 text-[var(--muted)]">{selectedProject.description}</p>
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              {selectedProject.stats.map((stat) => (
                <div key={stat} className="rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-4 text-sm font-medium">
                  {stat}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showContact && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/55 p-4 sm:items-center backdrop-blur-md">
          <div className="modal glass w-full max-w-xl p-6 sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-[0.3em] text-[var(--muted)]">StyleCraft Studio</div>
                <h3 className="mt-2 text-2xl font-bold">Let’s shape your next launch</h3>
              </div>
              <button onClick={() => setShowContact(false)} className="btn border border-[var(--border)] px-3 py-2 text-sm text-[var(--muted)] transition hover:text-[var(--text)]">
                Close
              </button>
            </div>
            <p className="mt-4 text-sm leading-7 text-[var(--muted)]">
              Strategy sessions, immersive product websites, scalable design systems, and frontend-ready prototypes for ambitious digital brands.
            </p>
            <div className="mt-6 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-alt)] p-4 text-sm text-[var(--muted)]">
              {submitted
                ? "Inquiry received. Expect a tailored response with timeline, scope, and design direction ideas."
                : "Use the form in the contact section below to test validation and submit your project details."}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
